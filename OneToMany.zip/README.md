<h1>Project Task Manager</h1>
<p>How to RUN</p>
<ul>
	<li>pertama kalian dapat download project ini terlebih dahulu</li>
	<li>kedua kalian harus menginstall composer dan laravel . </li>
	<li>ketiga import sql ke database mysql kalian , dengan nama database "taskmanager"</li>
	<li>setelah itu pindah project ini ke dalam directory htdocs</li>
	<li>setelah itu diekstrak (kalau belum di ekstrak)</li>
	<li>dan terakhir kalian bisa run porject ini dengan cara masuk ke directory project taskmanager ini , </li>
	<li>lalu shift + klik kanan lalu open command prompt here , dan ketikan "php artisan serve"</li>
	<li>setelah itu tinggal dibuka di browser kalian (eh jangan lupa hidupkan mysqli di xampp kalian ya.. hehe)</li>
</ul>