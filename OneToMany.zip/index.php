<?php
header('Location: public/');