@extends('layouts.app')
@section('content')

    <div class="container">
        <div class="row">
            <div class="col-md-12">
                <h1 class="display-4">
                    Welcome to my website
                </h1>
            </div>
        </div>
    </div>




@endsection